## Домашнее задание 4

Домашнее задание находится в homework.js

Необходимо решить ДЗ 4 до 30.12.2023 включительно (до 23:59), залить решение на гитхаб и скинуть ссылку гитхаба в [гугл форму](https://docs.google.com/forms/d/e/1FAIpQLSfLfwzWIEhtfF40s4oVKEFtNOHYRNNHUWK3bTPMxBaAwr_O7g/viewform)
